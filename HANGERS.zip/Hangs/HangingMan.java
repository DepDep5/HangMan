public class HangingMan {

    private int numWrongGuesses;
    private String[] HangmanImage = {"+----+\n"+
                                "|\n"+
                                "|\n"+
                                "|\n"+
                                "/\\\n",

                                "+----+\n"+
                                "|    O\n"+
                                "|\n"+
                                "|\n"+
                                "/\\\n",
                            
                                "+----+\n"+
                                "|    O\n"+
                                "|    +\n"+
                                "|\n"+
                                "/\\\n",
                            
                                "+----+\n"+
                                "|    O\n"+
                                "|    +-\n"+
                                "|\n"+
                                "/\\\n",
                                
                                
                                "+----+\n"+
                                "|    O\n"+
                                "|   -+-\n"+
                                "|\n"+
                                "/\\\n",
                                
                                
                                "+----+\n"+
                                "|    O\n"+
                                "|   -+-\n"+
                                "|   / \n"+
                                "/\\\n",
                                
                                
                                "+----+\n"+
                                "|    O\n"+
                                "|   -+-\n"+
                                "|   / \\\n"+
                                "/\\\n",
                            };
   public HangingMan() {
    }
   public void show() {
       System.out.println(HangmanImage[numWrongGuesses]);
   }
   public void dieSomeMore() {
       if (numWrongGuesses <= 7 -1) {
       numWrongGuesses++;
    } else {
        numWrongGuesses= 0;
    }
    }
   public boolean isntDead() {
       return numWrongGuesses < HangmanImage.length;
    }
}
