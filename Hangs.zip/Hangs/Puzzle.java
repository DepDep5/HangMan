import java.util.ArrayList;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class Puzzle
{
   private String puzzleAns;
   public Puzzle() {
       puzzleAns = "DLYAN";
    }
   public boolean isUnsolved() {
       if 
    }
   public void show() {
    }
   public void makeGuess() {
       if(guess.indexOf(
    }
}
