import java.util.ArrayList;
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;

public class Puzzle
{
    private String puzzleAns;
    private String guess;
    private String display;
    private String guesses;
    private int lettersGuessed;
    public Puzzle() {
        puzzleAns = "WHAT IF I PUT A NUMBER IN THIS LONG SENTENCE SO IT BECOMES CHALLENGING";
        display = displayDash();
        guesses = "Guesses: ";
        lettersGuessed = 0;
    }
    public boolean isUnsolved() {
        String check = "_";
        if (lettersGuessed < puzzleAns.length()) return true;
        return false;
    }
    public void show() {
        System.out.print("Puzzle:");
        System.out.println(display);
        System.out.println(guesses);
    }
    private String displayDash() {
        String d = "";
        for(int i = 0; i <= puzzleAns.length() - 1; i++) {
            d+="_ ";
        }
        return d;
    }
    public boolean makeGuess(String h) {
        String g = h.toUpperCase();
        boolean Ans = false;
        for (int i = 0; i <= puzzleAns.length() - 1; i++) {
                if (puzzleAns.substring(i, i + 1).equals(g)) {
                    display = display.substring(0, i*2) + g + display.substring(i*2+1);
                    Ans = true;
                    lettersGuessed++;
                }
        }
       
        guesses += g + ", ";
        return Ans;
    }

    public String getWord() {
        return puzzleAns;
    }
}
