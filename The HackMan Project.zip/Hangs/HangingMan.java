public class HangingMan {

    private int numWrongGuesses;
    private String[] HangmanImage = {
                                "be afraid of the cow\n\n\n\n\n\n",
                                
                                "           __n__n__\n\n\n\n\n\n",
        
                                "           __n__n__\n"+
                                "    .------`-\00/-'\n\n\n\n\n",
                            
                                "           __n__n__\n"+
                                "    .------`-\00/-'\n"+
                                "   /  ##  ## (oo)\n\n\n\n",
                                
                                
                                "           __n__n__\n"+
                                "    .------`-\00/-'\n"+
                                "   /  ##  ## (oo)\n"+
                                "  / \\## __   ./\n\n\n",
                                
                                
                                "           __n__n__\n"+
                                "    .------`-\00/-'\n"+
                                "   /  ##  ## (oo)\n"+
                                "  / \\## __   ./\n"+
                                "     |//YY \\|/\n\n",
                                
                                
                                "           __n__n__\n"+
                                "    .------`-\00/-'\n"+
                                "   /  ##  ## (oo)\n"+
                                "  / \\## __   ./\n"+
                                "     |//YY \\|/\n"+
                                "     |||   |||\n",
                                
                                "           __n__n__\n"+
                                "    .------`-\00/-'\n"+
                                "   /  ##  ## (oo)\n"+
                                "  / \\## __   ./\n"+
                                "     |//YY \\|/\n"+
                                "Moo  |||   |||\n",
                            };
   public HangingMan() {
    }
   public void show() {
       System.out.println(HangmanImage[numWrongGuesses]);
   }
   public void dieSomeMore() {
       if (numWrongGuesses <= HangmanImage.length - 1) {
       numWrongGuesses++;
    } else {
        numWrongGuesses= 0;
    }
    }
   public boolean isntDead() {
       return numWrongGuesses < HangmanImage.length;
    }
}
